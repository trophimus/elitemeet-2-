// Firebase Firestore Database Service
import { initializeApp } from 'firebase/app';
import { 
  getFirestore, 
  doc, 
  getDoc, 
  setDoc, 
  updateDoc, 
  collection, 
  query, 
  where, 
  addDoc, 
  getDocs,
  onSnapshot,
  serverTimestamp,
  orderBy
} from 'firebase/firestore';
import { getAuth, signInAnonymously, signInWithCustomToken, onAuthStateChanged } from 'firebase/auth';

// Define global variables for Firebase configuration provided by the Canvas environment
const appId = typeof __app_id !== 'undefined' ? __app_id : 'default-app-id';
const firebaseConfig = typeof __firebase_config !== 'undefined' ? JSON.parse(__firebase_config) : {};
const initialAuthToken = typeof __initial_auth_token !== 'undefined' ? __initial_auth_token : null;

// Initialize Firebase App
const app = initializeApp(firebaseConfig);
const db = getFirestore(app);
const auth = getAuth(app);

let currentUserId = null;
let isAuthReady = false;

// Authenticate user
const authenticateFirebase = async () => {
  try {
    if (initialAuthToken) {
      await signInWithCustomToken(auth, initialAuthToken);
      console.log('Signed in with custom token');
    } else {
      await signInAnonymously(auth);
      console.log('Signed in anonymously');
    }
  } catch (error) {
    console.error("Firebase authentication error:", error);
    // Fallback to anonymous sign-in if custom token fails or is not available
    try {
      await signInAnonymously(auth);
      console.log('Signed in anonymously after error');
    } catch (anonError) {
      console.error("Anonymous sign-in failed:", anonError);
    }
  }
};

// Set up auth state change listener
onAuthStateChanged(auth, (user) => {
  if (user) {
    currentUserId = user.uid;
    console.log("Auth State Changed: User is signed in with UID", currentUserId);
  } else {
    currentUserId = null;
    console.log("Auth State Changed: No user is signed in.");
  }
  isAuthReady = true;
});

// Ensure authentication happens when the module is loaded
authenticateFirebase();

const DatabaseService = {
  // Get current user ID
  getCurrentUserId: () => {
    // Return a random ID if not authenticated, as per instructions for non-authenticated users
    return currentUserId || crypto.randomUUID();
  },

  // --- User Profiles ---
  async createUserProfile(userId, userData) {
    if (!isAuthReady || !currentUserId) {
      console.warn("Firebase not ready or user not authenticated. Cannot create profile.");
      return { success: false, error: "Authentication not ready" };
    }
    const userRef = doc(db, `artifacts/${appId}/users/${userId}/private/profile`, userId);
    try {
      await setDoc(userRef, { ...userData, createdAt: serverTimestamp() }, { merge: true });
      return { success: true };
    } catch (error) {
      console.error("Error creating user profile:", error);
      return { success: false, error: error.message };
    }
  },

  async getUserProfile(userId) {
    if (!isAuthReady || !currentUserId) {
      console.warn("Firebase not ready or user not authenticated. Cannot get profile.");
      return { success: false, error: "Authentication not ready" };
    }
    const userRef = doc(db, `artifacts/${appId}/users/${userId}/private/profile`, userId);
    try {
      const docSnap = await getDoc(userRef);
      if (docSnap.exists()) {
        return { success: true, data: docSnap.data() };
      } else {
        return { success: false, error: "User profile not found" };
      }
    } catch (error) {
      console.error("Error fetching user profile:", error);
      return { success: false, error: error.message };
    }
  },

  async updateUserProfile(userId, updates) {
    if (!isAuthReady || !currentUserId) {
      console.warn("Firebase not ready or user not authenticated. Cannot update profile.");
      return { success: false, error: "Authentication not ready" };
    }
    const userRef = doc(db, `artifacts/${appId}/users/${userId}/private/profile`, userId);
    try {
      await updateDoc(userRef, { ...updates, updatedAt: serverTimestamp() });
      return { success: true };
    } catch (error) {
      console.error("Error updating user profile:", error);
      return { success: false, error: error.message };
    }
  },

  // --- Public Dating/Investor Profiles (for matching) ---
  async addPublicProfile(profileData) {
    if (!isAuthReady || !currentUserId) {
      console.warn("Firebase not ready or user not authenticated. Cannot add public profile.");
      return { success: false, error: "Authentication not ready" };
    }
    const publicProfilesRef = collection(db, `artifacts/${appId}/public/data/profiles`);
    try {
      const docRef = await addDoc(publicProfilesRef, { ...profileData, createdAt: serverTimestamp(), userId: currentUserId });
      return { success: true, id: docRef.id };
    } catch (error) {
      console.error("Error adding public profile:", error);
      return { success: false, error: error.message };
    }
  },

  onPublicProfilesSnapshot(callback) {
    if (!isAuthReady) {
      console.warn("Firebase not ready. Cannot attach public profiles snapshot listener.");
      return () => {}; // Return a no-op unsubscribe
    }
    const q = query(collection(db, `artifacts/${appId}/public/data/profiles`));
    const unsubscribe = onSnapshot(q, (snapshot) => {
      const profiles = [];
      snapshot.forEach(doc => {
        profiles.push({ id: doc.id, ...doc.data() });
      });
      callback(profiles);
    }, (error) => {
      console.error("Error listening to public profiles:", error);
    });
    return unsubscribe;
  },

  // --- Messaging ---
  async sendMessage(conversationId, senderId, receiverId, content) {
    if (!isAuthReady || !currentUserId) {
      console.warn("Firebase not ready or user not authenticated. Cannot send message.");
      return { success: false, error: "Authentication not ready" };
    }
    const messagesRef = collection(db, `artifacts/${appId}/public/data/conversations/${conversationId}/messages`);
    try {
      await addDoc(messagesRef, {
        senderId,
        receiverId,
        content,
        timestamp: serverTimestamp(),
      });
      // Update or create conversation metadata
      const conversationRef = doc(db, `artifacts/${appId}/public/data/conversations`, conversationId);
      await setDoc(conversationRef, {
        participants: [senderId, receiverId],
        lastMessage: content,
        lastMessageTimestamp: serverTimestamp(),
      }, { merge: true });
      return { success: true };
    } catch (error) {
      console.error("Error sending message:", error);
      return { success: false, error: error.message };
    }
  },

  onMessagesSnapshot(conversationId, callback) {
    if (!isAuthReady) {
      console.warn("Firebase not ready. Cannot attach messages snapshot listener.");
      return () => {};
    }
    const q = query(
      collection(db, `artifacts/${appId}/public/data/conversations/${conversationId}/messages`),
      orderBy('timestamp', 'asc') // Order by timestamp to get messages in chronological order
    );
    const unsubscribe = onSnapshot(q, (snapshot) => {
      const messages = [];
      snapshot.forEach(doc => {
        messages.push({ id: doc.id, ...doc.data() });
      });
      callback(messages);
    }, (error) => {
      console.error("Error listening to messages:", error);
    });
    return unsubscribe;
  },

  onConversationsSnapshot(userId, callback) {
    if (!isAuthReady) {
      console.warn("Firebase not ready. Cannot attach conversations snapshot listener.");
      return () => {};
    }
    const q = query(
      collection(db, `artifacts/${appId}/public/data/conversations`),
      where('participants', 'array-contains', userId)
    );
    const unsubscribe = onSnapshot(q, (snapshot) => {
      const conversations = [];
      snapshot.forEach(doc => {
        conversations.push({ id: doc.id, ...doc.data() });
      });
      callback(conversations);
    }, (error) => {
      console.error("Error listening to conversations:", error);
    });
    return unsubscribe;
  },

  // Helper to ensure auth is ready before operations
  isAuthInitialized: () => isAuthReady,
  getAuthInstance: () => auth,
};

export default DatabaseService;

