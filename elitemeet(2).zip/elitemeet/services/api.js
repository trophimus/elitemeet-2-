// API Service Layer

import axios from 'axios';
import { Platform } from 'react-native';
import AuthService from './auth'; // Import AuthService

// Configure base API URL
const BASE_URL = Platform.select({
  ios: 'http://localhost:3000/api',
  android: 'http://10.0.2.2:3000/api',
  web: 'https://api.elitemeet.com/v1'
});

const api = axios.create({
  baseURL: BASE_URL,
  timeout: 10000,
  headers: {
    'Content-Type': 'application/json',
    'X-Client-Type': 'mobile-app'
  }
});

// Add auth token to requests
api.interceptors.request.use(async config => {
  const token = await AuthService.getToken(); // Use await as getToken is async
  if (token) {
    config.headers.Authorization = `Bearer ${token}`;
  }
  return config;
});

const ApiService = {
  // User endpoints
  login: (email, password) => api.post('/auth/login', { email, password }),
  register: (userData) => api.post('/auth/register', userData),
  verifyAccount: (token) => api.post('/auth/verify', { token }),
  getProfile: () => api.get('/users/me'),
  updateProfile: (profileData) => api.patch('/users/me', profileData),

  // Matching endpoints
  getDatingProfiles: (filters) => api.get('/matching/dating', { params: filters }),
  getInvestorProfiles: (filters) => api.get('/matching/investors', { params: filters }),
  sendLike: (userId) => api.post(`/matching/like/${userId}`),
  sendDislike: (userId) => api.post(`/matching/dislike/${userId}`),

  // Messaging endpoints
  getConversations: () => api.get('/messaging/conversations'),
  getMessages: (conversationId) => api.get(`/messaging/conversations/${conversationId}`),
  sendMessage: (conversationId, content) => api.post(`/messaging/conversations/${conversationId}`, { content }),

  // Admin endpoints
  verifyUser: (userId) => api.post(`/admin/verify/${userId}`),
  reportUser: (userId, reason) => api.post(`/admin/report/${userId}`, { reason }),

  // Error handling wrapper
  async safeRequest(promise) {
    try {
      const response = await promise;
      return { data: response.data, error: null };
    } catch (error) {
      console.error('API Error:', error.response?.data || error.message);
      return { 
        data: null, 
        error: error.response?.data?.message || 'Network error occurred' 
      };
    }
  }
};

export default ApiService;
