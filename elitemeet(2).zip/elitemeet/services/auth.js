// Authentication Service

// for user

import SecureStore from 'expo-secure-store';
import ApiService from './api'; // Ensure correct import path

const TOKEN_KEY = 'elitemeet_auth_token';
const USER_DATA_KEY = 'elitemeet_user_data';

const AuthService = {
  // Login with email/password
  async login(email, password) {
    const { data, error } = await ApiService.safeRequest(
      ApiService.login(email, password)
    );
    
    if (data) {
      await this._storeAuthData(data);
      return { success: true, user: data.user };
    }
    return { success: false, error: error || 'Login failed' };
  },

  // Register new elite member
  async register(userData) {
    const { data, error } = await ApiService.safeRequest(
      ApiService.register(userData)
    );
    
    if (data) {
      await this._storeAuthData(data);
      return { success: true, user: data.user };
    }
    return { success: false, error: error || 'Registration failed' };
  },

  // Verify account with token
  async verifyAccount(token) {
    const { data, error } = await ApiService.safeRequest(
      ApiService.verifyAccount(token)
    );
    return { success: !!data, error };
  },

  // Logout user
  async logout() {
    await this._clearAuthData();
    return { success: true };
  },

  // Check if user is authenticated
  async isAuthenticated() {
    const token = await this.getToken();
    return !!token;
  },

  // Get stored token
  async getToken() {
    try {
      return await SecureStore.getItemAsync(TOKEN_KEY);
    } catch (error) {
      console.error('Failed to get token:', error);
      return null;
    }
  },

  // Get user data
  async getUserData() {
    try {
      const userData = await SecureStore.getItemAsync(USER_DATA_KEY);
      return userData ? JSON.parse(userData) : null;
    } catch (error) {
      console.error('Failed to get user data:', error);
      return null;
    }
  },

  // Update user data in storage
  async updateUserData(userData) {
    try {
      await SecureStore.setItemAsync(USER_DATA_KEY, JSON.stringify(userData));
      return true;
    } catch (error) {
      console.error('Failed to update user data:', error);
      return false;
    }
  },

  // Private methods
  async _storeAuthData(authData) {
    try {
      await SecureStore.setItemAsync(TOKEN_KEY, authData.token);
      await SecureStore.setItemAsync(USER_DATA_KEY, JSON.stringify(authData.user));
    } catch (error) {
      console.error('Failed to store auth data:', error);
      throw error;
    }
  },

  async _clearAuthData() {
    try {
      await SecureStore.deleteItemAsync(TOKEN_KEY);
      await SecureStore.deleteItemAsync(USER_DATA_KEY);
    } catch (error) {
      console.error('Failed to clear auth data:', error);
      throw error;
    }
  },

  // Social login methods (placeholders)
  async loginWithGoogle(token) {
    // Implementation for Google OAuth
    console.log("Google login attempted with token:", token);
    return { success: false, error: 'Google login not implemented.' };
  },

  async loginWithApple(token) {
    // Implementation for Apple Sign-In
    console.log("Apple login attempted with token:", token);
    return { success: false, error: 'Apple login not implemented.' };
  },

  // Biometric authentication (placeholder)
  async enableBiometricAuth() {
    console.log("Biometric authentication not implemented.");
    return { success: false, error: 'Biometric authentication not implemented.' };
  }
};

export default AuthService;
