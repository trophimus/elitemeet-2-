// Investors Page

import React, { useState, useEffect } from 'react';
import { View, Text, TextInput, ScrollView, TouchableOpacity, ActivityIndicator } from 'react-native';
import { Search, Briefcase, DollarSign, BarChart2, Filter } from 'lucide-react-native';
import { Card } from 'react-native-paper';
import { styles } from '../assets/styles';

const InvestorsScreen = () => {
  const [investors, setInvestors] = useState([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [loading, setLoading] = useState(true);
  const [activeFilter, setActiveFilter] = useState('all');

  // Mock API call
  useEffect(() => {
    setTimeout(() => {
      setInvestors([
        {
          id: '1',
          name: 'James Wilson',
          title: 'Angel Investor',
          company: 'Wilson Ventures',
          focus: 'Tech Startups',
          aum: '$50M',
          checkSize: '$100K-$1M',
          verified: true
        },
        {
          id: '2',
          name: 'Priya Patel',
          title: 'VC Partner',
          company: 'Horizon Capital',
          focus: 'Biotech',
          aum: '$200M',
          checkSize: '$1M-$5M',
          verified: true
        }
      ]);
      setLoading(false);
    }, 1000);
  }, []);

  const filteredInvestors = investors.filter(investor => {
    const matchesSearch = investor.name.toLowerCase().includes(searchQuery.toLowerCase()) || 
                         investor.company.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesFilter = activeFilter === 'all' || 
                         investor.focus.toLowerCase().includes(activeFilter.toLowerCase());
    return matchesSearch && matchesFilter;
  });

  return (
    <View style={styles.homeContainer}>
      {/* Search Bar */}
      <View style={styles.searchBar}>
        <Search size={20} color="#94A3B8" style={styles.searchIcon} />
        <TextInput
          placeholder="Search investors..."
          placeholderTextColor="#94A3B8"
          style={styles.searchInput}
          value={searchQuery}
          onChangeText={setSearchQuery}
        />
        <TouchableOpacity>
          <Filter size={20} color="#8B5CF6" />
        </TouchableOpacity>
      </View>

      {/* Investment Focus Filters */}
      <ScrollView horizontal showsHorizontalScrollIndicator={false} style={{marginBottom: 16}}>
        <View style={{flexDirection: 'row', gap: 8}}>
          {['All', 'Tech', 'Biotech', 'Fintech', 'Real Estate'].map((filter) => (
            <TouchableOpacity
              key={filter}
              style={[
                styles.modeButton,
                activeFilter === filter.toLowerCase() && styles.activeModeButton
              ]}
              onPress={() => setActiveFilter(filter === 'All' ? 'all' : filter.toLowerCase())}
            >
              <Text style={[
                styles.modeButtonText,
                activeFilter === filter.toLowerCase() && styles.activeModeButtonText
              ]}>
                {filter}
              </Text>
            </TouchableOpacity>
          ))}
        </View>
      </ScrollView>

      {/* Investor List */}
      {loading ? (
        <ActivityIndicator size="large" color="#8B5CF6" style={{flex: 1}} />
      ) : (
        <ScrollView>
          {filteredInvestors.map((investor) => (
            <Card key={investor.id} style={[styles.card, {marginBottom: 12}]}>
              <Card.Content>
                <View style={{flexDirection: 'row', justifyContent: 'space-between'}}>
                  <View>
                    <Text style={styles.name}>{investor.name}</Text>
                    <Text style={styles.title}>{investor.title}</Text>
                    <Text style={styles.company}>{investor.company}</Text>
                  </View>
                  {investor.verified && (
                    <Text style={styles.verifiedBadge}>✓ Verified</Text>
                  )}
                </View>

                <View style={{flexDirection: 'row', marginTop: 16, gap: 16}}>
                  <View style={{flexDirection: 'row', alignItems: 'center'}}>
                    <Briefcase size={16} color="#8B5CF6" />
                    <Text style={styles.details}>{investor.focus}</Text>
                  </View>
                  <View style={{flexDirection: 'row', alignItems: 'center'}}>
                    <DollarSign size={16} color="#8B5CF6" />
                    <Text style={styles.details}>{investor.checkSize}</Text>
                  </View>
                  <View style={{flexDirection: 'row', alignItems: 'center'}}>
                    <BarChart2 size={16} color="#8B5CF6" />
                    <Text style={styles.details}>{investor.aum}</Text>
                  </View>
                </View>

                <View style={{flexDirection: 'row', gap: 8, marginTop: 16}}>
                  <TouchableOpacity style={[styles.button, {flex: 1}]}>
                    <Text style={styles.buttonText}>Connect</Text>
                  </TouchableOpacity>
                  <TouchableOpacity style={[styles.button, {flex: 1, backgroundColor: '#1E293B'}]}>
                    <Text style={[styles.buttonText, {color: '#8B5CF6'}]}>Message</Text>
                  </TouchableOpacity>
                </View>
              </Card.Content>
            </Card>
          ))}
        </ScrollView>
      )}
    </View>
  );
};

export default InvestorsScreen;