// LLMAdviceScreen.js - Screen for interacting with the LLM for advice and NDA generation
import React, { useState, useEffect } from 'react';
import { 
  View, 
  Text, 
  TextInput, 
  TouchableOpacity, 
  ScrollView, 
  ActivityIndicator,
  Alert // For mock feedback, replace with custom UI
} from 'react-native';
import { Lightbulb, Briefcase, Heart, FileText, Send, DollarSign } from 'lucide-react-native'; // Added DollarSign
import { styles } from '../assets/styles';

const LLMAdviceScreen = () => {
  const [query, setQuery] = useState('');
  const [llmResponse, setLlmResponse] = useState('');
  const [loading, setLoading] = useState(false);
  const [activeCategory, setActiveCategory] = useState('general'); // 'dating', 'business', 'investing', 'nda'

  // LLM API Configuration (Placeholder)
  // In a real app, this would be secured and called from a backend or a cloud function.
  // For this example, we'll use a direct client-side call to Gemini API.
  const API_KEY = ""; // Canvas will provide this at runtime if empty.
  const API_URL = `https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent?key=${API_KEY}`;

  const getPromptForCategory = (category, userQuery) => {
    switch (category) {
      case 'dating':
        return `As an expert dating coach, provide concise and actionable dating advice based on this query: "${userQuery}"`;
      case 'business':
        return `As a seasoned business consultant, provide strategic business advice relevant to this query: "${userQuery}"`;
      case 'investing':
        return `As a financial advisor with expertise in elite investments, provide insights and advice on: "${userQuery}"`;
      case 'nda':
        return `Generate a simple, standard Non-Disclosure Agreement (NDA) with placeholders for parties involved and purpose, based on this request: "${userQuery}"`;
      default:
        return `Provide general advice or information on: "${userQuery}"`;
    }
  };

  const handleGenerateResponse = async () => {
    if (!query.trim()) {
      Alert.alert("Input Required", "Please enter your question or request.");
      return;
    }

    setLoading(true);
    setLlmResponse(''); // Clear previous response
    let chatHistory = [];
    const prompt = getPromptForCategory(activeCategory, query);
    chatHistory.push({ role: "user", parts: [{ text: prompt }] });

    const payload = {
      contents: chatHistory,
      generationConfig: {
        // You can add specific generation parameters here, e.g., temperature, topK, topP
        // temperature: 0.7,
        // maxOutputTokens: 500,
      }
    };

    try {
      const response = await fetch(API_URL, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(payload)
      });

      const result = await response.json();

      if (result.candidates && result.candidates.length > 0 &&
          result.candidates[0].content && result.candidates[0].content.parts &&
          result.candidates[0].content.parts.length > 0) {
        const text = result.candidates[0].content.parts[0].text;
        setLlmResponse(text);
      } else {
        setLlmResponse("Sorry, I couldn't generate a response for that. Please try again.");
        console.error("LLM API response structure unexpected:", result);
      }
    } catch (error) {
      console.error("Error calling LLM API:", error);
      setLlmResponse("An error occurred while connecting to the advice service. Please try again later.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <View style={styles.llmContainer}>
      <Text style={styles.llmTitle}>Elite AI Assistant</Text>

      {/* Category Selection */}
      <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={styles.adviceOptions}>
        <TouchableOpacity
          style={[styles.adviceButton, activeCategory === 'dating' && styles.activeAdviceButton]}
          onPress={() => setActiveCategory('dating')}
        >
          <View style={{flexDirection: 'row', alignItems: 'center'}}>
            <Heart size={16} color={activeCategory === 'dating' ? '#FFFFFF' : '#8B5CF6'} />
            <Text style={[styles.adviceButtonText, activeCategory === 'dating' && {color: '#FFFFFF'}]}> Dating Advice</Text>
          </View>
        </TouchableOpacity>
        <TouchableOpacity
          style={[styles.adviceButton, activeCategory === 'business' && styles.activeAdviceButton]}
          onPress={() => setActiveCategory('business')}
        >
          <View style={{flexDirection: 'row', alignItems: 'center'}}>
            <Briefcase size={16} color={activeCategory === 'business' ? '#FFFFFF' : '#8B5CF6'} />
            <Text style={[styles.adviceButtonText, activeCategory === 'business' && {color: '#FFFFFF'}]}> Business Advice</Text>
          </View>
        </TouchableOpacity>
        <TouchableOpacity
          style={[styles.adviceButton, activeCategory === 'investing' && styles.activeAdviceButton]}
          onPress={() => setActiveCategory('investing')}
        >
          <View style={{flexDirection: 'row', alignItems: 'center'}}>
            <DollarSign size={16} color={activeCategory === 'investing' ? '#FFFFFF' : '#8B5CF6'} />
            <Text style={[styles.adviceButtonText, activeCategory === 'investing' && {color: '#FFFFFF'}]}> Investing Advice</Text>
          </View>
        </TouchableOpacity>
        <TouchableOpacity
          style={[styles.adviceButton, activeCategory === 'nda' && styles.activeAdviceButton]}
          onPress={() => setActiveCategory('nda')}
        >
          <View style={{flexDirection: 'row', alignItems: 'center'}}>
            <FileText size={16} color={activeCategory === 'nda' ? '#FFFFFF' : '#8B5CF6'} />
            <Text style={[styles.adviceButtonText, activeCategory === 'nda' && {color: '#FFFFFF'}]}> Generate NDA</Text>
          </View>
        </TouchableOpacity>
      </ScrollView>

      {/* Input Field */}
      <View style={styles.inputContainer}>
        <Lightbulb size={20} color="#94A3B8" style={styles.inputIcon} />
        <TextInput
          style={[styles.authInput, {flex: 1}]}
          placeholder={`Ask me about ${activeCategory === 'nda' ? 'your NDA' : activeCategory} or generate an NDA...`}
          placeholderTextColor="#64748B"
          value={query}
          onChangeText={setQuery}
          multiline
          numberOfLines={3}
        />
        <TouchableOpacity 
          style={styles.sendButton} 
          onPress={handleGenerateResponse}
          disabled={loading}
        >
          {loading ? (
            <ActivityIndicator size="small" color="#FFFFFF" />
          ) : (
            <Send size={20} color="#FFFFFF" />
          )}
        </TouchableOpacity>
      </View>

      {/* LLM Output */}
      <ScrollView style={styles.llmOutputContainer}>
        {llmResponse ? (
          <Text style={styles.llmOutputText}>{llmResponse}</Text>
        ) : (
          <Text style={[styles.llmOutputText, {color: '#64748B'}]}>Your AI-powered advice and documents will appear here.</Text>
        )}
      </ScrollView>
    </View>
  );
};

export default LLMAdviceScreen;
