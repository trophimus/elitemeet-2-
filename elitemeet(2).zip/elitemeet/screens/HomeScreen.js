// HomeScreen.js - Start Page
// Home Screen - Start Page
import React, { useState, useEffect } from 'react';
import { View, Text, TextInput, ScrollView, ActivityIndicator, TouchableOpacity } from 'react-native';
import { Bell, MessageCircle, Search, User, Lightbulb } from 'lucide-react-native';
import { LinearGradient } from 'expo-linear-gradient'; // Import LinearGradient
import ModeSwitcher from '../components/ModeSwitcher';
import ProfileCard from '../components/ProfileCard'; // Ensure ProfileCard is imported
import { styles } from '../assets/styles';
import DatabaseService from '../database/Database'; // Import DatabaseService

export default function HomeScreen({ navigation }) {
  const [activeTab, setActiveTab] = useState('dating');
  const [searchQuery, setSearchQuery] = useState('');
  const [allProfiles, setAllProfiles] = useState([]); // Stores all profiles from Firestore
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    let unsubscribe;

    const initializeProfiles = async () => {
      setLoading(true);
      // Ensure DatabaseService is initialized before trying to fetch data
      while (!DatabaseService.isAuthInitialized()) {
        await new Promise(resolve => setTimeout(resolve, 100));
      }

      // Listen for real-time updates to public profiles
      // Filter profiles that have a 'type' field matching 'dating' or 'investor'
      unsubscribe = DatabaseService.onPublicProfilesSnapshot((profiles) => {
        setAllProfiles(profiles);
        setLoading(false);
      });
    };

    initializeProfiles();

    // Cleanup subscription on component unmount
    return () => {
      if (unsubscribe) {
        unsubscribe();
      }
    };
  }, []); // Empty dependency array means this runs once on mount

  // Filter profiles based on activeTab and searchQuery
  const filteredProfiles = allProfiles.filter(profile => {
    // Ensure profile.type exists before comparing
    const matchesTab = profile.type === activeTab; 
    const matchesSearch = profile.name?.toLowerCase().includes(searchQuery.toLowerCase()) ||
                          profile.title?.toLowerCase().includes(searchQuery.toLowerCase()) ||
                          (profile.company && profile.company.toLowerCase().includes(searchQuery.toLowerCase()));
    return matchesTab && matchesSearch;
  });

  return (
    <View style={styles.homeContainer}>
      {/* Header */}
      <View style={styles.header}>
        {/* App Title with LinearGradient */}
        <LinearGradient
          colors={['#8B5CF6', '#EC4899']} // Your specified colors
          start={{ x: 0, y: 0 }}
          end={{ x: 1, y: 0}}
          style={styles.appTitleContainer}> {/* You might need to add appTitleContainer style */}
          <Text style={styles.appTitle}>EliteMeet</Text>
        </LinearGradient>
        <View style={styles.icons}>
          <TouchableOpacity onPress={() => navigation.navigate('LLMAdvice')}>
            <Lightbulb size={24} color="#94A3B8" />
          </TouchableOpacity>
          <TouchableOpacity onPress={() => navigation.navigate('Chat', { conversationId: DatabaseService.getCurrentUserId() + '_inbox', otherUserName: 'Messages' })}>
            <MessageCircle size={24} color="#94A3B8" style={{ marginLeft: 20 }} />
          </TouchableOpacity>
          <TouchableOpacity onPress={() => navigation.navigate('ProfileEdit')}>
            <User size={24} color="#94A3B8" style={{ marginLeft: 20 }} />
          </TouchableOpacity>
        </View>
      </View>

      {/* Mode Switcher */}
      <ModeSwitcher activeTab={activeTab} setActiveTab={setActiveTab} />

      {/* Search Bar */}
      <View style={styles.searchBar}>
        <Search size={20} color="#94A3B8" style={styles.searchIcon} />
        <TextInput
          placeholder={activeTab === 'dating' ? 'Find your perfect match...' : 'Search investors...'}
          placeholderTextColor="#94A3B8"
          style={styles.searchInput}
          value={searchQuery}
          onChangeText={setSearchQuery}
        />
      </View>

      {/* Profiles */}
      {loading ? (
        <ActivityIndicator size="large" color="#8B5CF6" style={{ flex: 1 }} />
      ) : (
        <ScrollView>
          {filteredProfiles.length > 0 ? (
            filteredProfiles.map((profile) => (
              <ProfileCard
                key={profile.id}
                profile={profile}
                mode={activeTab} // Pass mode to ProfileCard if it needs to render differently
                onPress={() => {
                  // For navigating to detailed screens, you might need to adjust
                  // how DatingScreen and InvestorsScreen consume this data.
                  // For now, we'll navigate to the main screens.
                  if (activeTab === 'dating') {
                    navigation.navigate('Dating'); 
                  } else {
                    navigation.navigate('Investors');
                  }
                }}
              />
            ))
          ) : (
            <Text style={{ color: '#94A3B8', textAlign: 'center', marginTop: 50 }}>
              No {activeTab} profiles found. Try adjusting your search or filters.
            </Text>
          )}
        </ScrollView>
      )}
    </View>
  );
}
