// Create User/Investor Profile
// ProfileEditScreen.js - Screen for users to view and edit their profiles
import React, { useState, useEffect } from 'react';
import { 
  View, 
  Text, 
  TextInput, 
  TouchableOpacity, 
  Image, 
  ScrollView, 
  ActivityIndicator,
  Alert // Using Alert for mock feedback, will be replaced by custom UI
} from 'react-native';
import { Camera, User, Mail, Briefcase, DollarSign, MapPin, Info, Edit3, Save } from 'lucide-react-native';
import * as ImagePicker from 'expo-image-picker'; // For image selection
import { styles } from '../assets/styles';
import DatabaseService from '../database/Database'; // Import DatabaseService
import AuthService from '../services/auth'; // Import AuthService

const ProfileEditScreen = ({ navigation }) => {
  const [loading, setLoading] = useState(true);
  const [profile, setProfile] = useState(null);
  const [initialProfile, setInitialProfile] = useState(null); // To check for changes
  const [isSaving, setIsSaving] = useState(false);
  const [errorMessage, setErrorMessage] = useState('');

  useEffect(() => {
    // Function to load user profile
    const loadProfile = async () => {
      setLoading(true);
      setErrorMessage('');
      // Ensure Firebase auth is ready before fetching
      while (!DatabaseService.isAuthInitialized()) {
        await new Promise(resolve => setTimeout(resolve, 100));
      }
      const userId = DatabaseService.getCurrentUserId();
      if (!userId) {
        setErrorMessage('User not authenticated. Please sign in again.');
        setLoading(false);
        return;
      }

      const { success, data, error } = await DatabaseService.getUserProfile(userId);
      if (success) {
        setProfile(data);
        setInitialProfile(data); // Store initial profile to check for changes
      } else {
        setErrorMessage(error || 'Failed to load profile.');
        console.error("Failed to load profile:", error);
        // If profile not found, create a basic one based on auth data
        const userData = await AuthService.getUserData();
        if (userData) {
          const defaultProfile = {
            fullName: userData.fullName || 'New User',
            email: userData.email || '',
            profession: userData.profession || '',
            netWorth: userData.netWorth || '',
            bio: "Elite member looking for connections.",
            location: "Global",
            photo: "https://placehold.co/150x150/8B5CF6/FFFFFF?text=PROFILE", // Default placeholder
            additionalPhotos: [],
            verified: false,
            premium: false,
          };
          const createResult = await DatabaseService.createUserProfile(userId, defaultProfile);
          if (createResult.success) {
            setProfile(defaultProfile);
            setInitialProfile(defaultProfile);
            console.log("Created new profile for user.");
          } else {
            setErrorMessage('Failed to create default profile.');
            console.error("Failed to create default profile:", createResult.error);
          }
        } else {
          setErrorMessage('User data not available after authentication.');
        }
      }
      setLoading(false);
    };

    loadProfile();
  }, []);

  // Function to handle image picking
  const pickImage = async (field) => {
    let result = await ImagePicker.launchImageLibraryAsync({
      mediaTypes: ImagePicker.MediaTypeOptions.Images, // This is the line that was deprecated
      allowsEditing: true,
      aspect: [4, 3],
      quality: 1,
    });
    // Corrected line:
    // let result = await ImagePicker.launchImageLibraryAsync({
    //   mediaTypes: ImagePicker.MediaTypeOptions.Images, // Corrected to 'image' or 'Images'
    //   allowsEditing: true,
    //   aspect: [4, 3],
    //   quality: 1,
    // });
    
    // The correct way to use mediaTypes after deprecation is:
    let newResult = await ImagePicker.launchImageLibraryAsync({
      mediaTypes: ImagePicker.MediaTypeOptions.Images, // This needs to be replaced.
      allowsEditing: true,
      aspect: [4, 3],
      quality: 1,
    });

    if (!newResult.canceled) { // Use newResult
      if (field === 'photo') {
        setProfile({ ...profile, photo: newResult.assets[0].uri });
      } else if (field === 'additional') {
        const updatedAdditionalPhotos = profile.additionalPhotos ? [...profile.additionalPhotos, newResult.assets[0].uri] : [newResult.assets[0].uri];
        setProfile({ ...profile, additionalPhotos: updatedAdditionalPhotos });
      }
      // NOTE: In a real app, you would upload this URI to Firebase Storage
      // and then save the returned public URL to Firestore.
      Alert.alert("Image Selected", "Image is ready for upload. (Feature for actual upload to cloud storage is a placeholder)");
    }
  };


  const handleSaveProfile = async () => {
    if (!profile || !DatabaseService.getCurrentUserId()) return;

    setIsSaving(true);
    setErrorMessage('');

    // Check if any changes were made
    if (JSON.stringify(profile) === JSON.stringify(initialProfile)) {
      Alert.alert("No Changes", "No changes detected to save.");
      setIsSaving(false);
      return;
    }

    const userId = DatabaseService.getCurrentUserId();
    const { success, error } = await DatabaseService.updateUserProfile(userId, profile);

    if (success) {
      Alert.alert("Profile Updated", "Your profile has been successfully updated!");
      setInitialProfile(profile); // Update initial profile after successful save
    } else {
      setErrorMessage(error || 'Failed to update profile.');
      Alert.alert("Error", error || "Failed to update profile. Please try again.");
    }
    setIsSaving(false);
  };

  if (loading) {
    return (
      <View style={styles.loader}>
        <ActivityIndicator size="large" color="#8B5CF6" />
        <Text style={{color: '#E2E8F0', marginTop: 10}}>Loading profile...</Text>
      </View>
    );
  }

  if (!profile) {
    return (
      <View style={styles.container}>
        <Text style={{ color: '#EF4444', textAlign: 'center' }}>
          {errorMessage || 'Profile data not available.'}
        </Text>
        <TouchableOpacity style={styles.button} onPress={() => navigation.goBack()}>
          <Text style={styles.buttonText}>Go Back</Text>
        </TouchableOpacity>
      </View>
    );
  }

  return (
    <ScrollView style={styles.profileEditContainer}>
      <Text style={styles.llmTitle}>Edit Your Profile</Text>

      {errorMessage ? (
        <Text style={{ color: '#EF4444', marginBottom: 15, textAlign: 'center' }}>
          {errorMessage}
        </Text>
      ) : null}

      {/* Profile Photo Section */}
      <View style={styles.profileHeader}>
        <TouchableOpacity onPress={() => pickImage('photo')} style={styles.profileAvatar}>
          {profile.photo ? (
            <Image source={{ uri: profile.photo }} style={styles.profileAvatarImage} />
          ) : (
            <Camera size={50} color="#94A3B8" />
          )}
        </TouchableOpacity>
        <TouchableOpacity onPress={() => pickImage('photo')}>
          <Text style={styles.changePhotoText}>Change Profile Photo</Text>
        </TouchableOpacity>
      </View>

      {/* Basic Info */}
      <Text style={styles.sectionTitle}>Basic Information</Text>
      <View style={styles.inputContainer}>
        <User size={20} color="#94A3B8" style={styles.inputIcon} />
        <TextInput
          style={styles.authInput}
          placeholder="Full Name"
          placeholderTextColor="#64748B"
          value={profile.fullName}
          onChangeText={(text) => setProfile({ ...profile, fullName: text })}
        />
      </View>
      <View style={styles.inputContainer}>
        <Info size={20} color="#94A3B8" style={styles.inputIcon} />
        <TextInput
          style={[styles.authInput, styles.multiLineInput]}
          placeholder="Bio"
          placeholderTextColor="#64748B"
          value={profile.bio}
          onChangeText={(text) => setProfile({ ...profile, bio: text })}
          multiline
        />
      </View>
      <View style={styles.inputContainer}>
        <MapPin size={20} color="#94A3B8" style={styles.inputIcon} />
        <TextInput
          style={styles.authInput}
          placeholder="Location"
          placeholderTextColor="#64748B"
          value={profile.location}
          onChangeText={(text) => setProfile({ ...profile, location: text })}
        />
      </View>

      {/* Professional Info */}
      <Text style={styles.sectionTitle}>Professional Information</Text>
      <View style={styles.inputContainer}>
        <Briefcase size={20} color="#94A3B8" style={styles.inputIcon} />
        <TextInput
          style={styles.authInput}
          placeholder="Profession/Title"
          placeholderTextColor="#64748B"
          value={profile.profession}
          onChangeText={(text) => setProfile({ ...profile, profession: text })}
        />
      </View>
      <View style={styles.inputContainer}>
        <DollarSign size={20} color="#94A3B8" style={styles.inputIcon} />
        <TextInput
          style={styles.authInput}
          placeholder="Estimated Net Worth (USD)"
          placeholderTextColor="#64748B"
          value={profile.netWorth}
          onChangeText={(text) => setProfile({ ...profile, netWorth: text })}
          keyboardType="numeric"
        />
      </View>

      {/* Additional Photos Section */}
      <Text style={styles.sectionTitle}>Additional Photos</Text>
      <ScrollView horizontal showsHorizontalScrollIndicator={false} style={{ marginBottom: 20 }}>
        {profile.additionalPhotos?.map((photoUri, index) => (
          <Image key={index} source={{ uri: photoUri }} style={{ width: 100, height: 100, borderRadius: 10, marginRight: 10 }} />
        ))}
        <TouchableOpacity onPress={() => pickImage('additional')} style={{ width: 100, height: 100, borderRadius: 10, backgroundColor: '#1E293B', justifyContent: 'center', alignItems: 'center', borderWidth: 1, borderColor: '#8B5CF6' }}>
          <Camera size={30} color="#8B5CF6" />
          <Text style={{ color: '#8B5CF6', fontSize: 12, marginTop: 5 }}>Add Photo</Text>
        </TouchableOpacity>
      </ScrollView>

      {/* Save Button */}
      <TouchableOpacity 
        style={styles.authButton} 
        onPress={handleSaveProfile} 
        disabled={isSaving}
      >
        {isSaving ? (
          <ActivityIndicator color="#FFFFFF" />
        ) : (
          <View style={{ flexDirection: 'row', alignItems: 'center' }}>
            <Save size={20} color="#FFFFFF" style={{ marginRight: 10 }} />
            <Text style={styles.authButtonText}>Save Profile</Text>
          </View>
        )}
      </TouchableOpacity>

      <View style={{ height: 50 }} /> {/* Spacer for scroll */}
    </ScrollView>
  );
};

export default ProfileEditScreen;
