import React, { useState } from 'react';
import { 
  View, 
  Text, 
  TextInput, 
  TouchableOpacity, 
  ScrollView, 
  StyleSheet,
  KeyboardAvoidingView,
  Platform,
  Image,
  Alert
} from 'react-native';
import { User, Briefcase, DollarSign, Award, MapPin, ChevronDown, Camera, Image as ImageIcon } from 'lucide-react-native';
import * as ImagePicker from 'expo-image-picker';
import * as Permissions from 'expo-permissions';

const JoinScreen = ({ navigation }) => {
  const [userType, setUserType] = useState('entrepreneur');
  const [profileImage, setProfileImage] = useState(null);
  const [formData, setFormData] = useState({
    name: '',
    profession: '',
    location: '',
    bio: '',
    startupName: '',
    fundingStage: '',
    industry: '',
    investmentFocus: '',
    typicalCheckSize: '',
    aum: ''
  });

  const requestPermission = async () => {
    const { status } = await Permissions.askAsync(Permissions.CAMERA_ROLL);
    if (status !== 'granted') {
      Alert.alert('Permission required', 'We need camera roll permissions to upload your profile picture');
      return false;
    }
    return true;
  };

  const pickImage = async () => {
    const hasPermission = await requestPermission();
    if (!hasPermission) return;

    let result = await ImagePicker.launchImageLibraryAsync({
      mediaTypes: ImagePicker.MediaTypeOptions.Images,
      allowsEditing: true,
      aspect: [1, 1],
      quality: 0.8,
    });

    if (!result.cancelled) {
      setProfileImage(result.uri);
    }
  };

  const takePhoto = async () => {
    const hasPermission = await requestPermission();
    if (!hasPermission) return;

    let result = await ImagePicker.launchCameraAsync({
      allowsEditing: true,
      aspect: [1, 1],
      quality: 0.8,
    });

    if (!result.cancelled) {
      setProfileImage(result.uri);
    }
  };

  const handleSubmit = () => {
    // Add your form submission logic here
    const userData = {
      ...formData,
      profileImage,
      userType
    };
    console.log('Submitting:', userData);
    navigation.navigate('Verification', { userData });
  };

  const updateFormData = (field, value) => {
    setFormData({
      ...formData,
      [field]: value
    });
  };

  return (
    <KeyboardAvoidingView
      behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
      style={styles.container}
    >
      <ScrollView contentContainerStyle={styles.scrollContainer}>
        <Text style={styles.header}>Complete Your Elite Profile</Text>
        
        {/* Profile Picture Upload */}
        <View style={styles.profileImageContainer}>
          {profileImage ? (
            <Image source={{ uri: profileImage }} style={styles.profileImage} />
          ) : (
            <View style={styles.profileImagePlaceholder}>
              <User size={48} color="#64748B" />
            </View>
          )}
          
          <View style={styles.imageUploadButtons}>
            <TouchableOpacity 
              style={styles.imageUploadButton}
              onPress={pickImage}
            >
              <ImageIcon size={20} color="#FFFFFF" />
              <Text style={styles.imageUploadButtonText}>Choose Photo</Text>
            </TouchableOpacity>
            
            <TouchableOpacity 
              style={styles.imageUploadButton}
              onPress={takePhoto}
            >
              <Camera size={20} color="#FFFFFF" />
              <Text style={styles.imageUploadButtonText}>Take Photo</Text>
            </TouchableOpacity>
          </View>
        </View>

        {/* Rest of your form remains the same */}
        {/* ... (Previous form code) ... */}

        <TouchableOpacity style={styles.submitButton} onPress={handleSubmit}>
          <Text style={styles.submitButtonText}>Continue to Verification</Text>
        </TouchableOpacity>
      </ScrollView>
    </KeyboardAvoidingView>
  );
};

const styles = StyleSheet.create({
  // ... (Previous styles remain the same) ...
  
  profileImageContainer: {
    alignItems: 'center',
    marginBottom: 24,
  },
  profileImage: {
    width: 150,
    height: 150,
    borderRadius: 75,
    marginBottom: 16,
  },
  profileImagePlaceholder: {
    width: 150,
    height: 150,
    borderRadius: 75,
    backgroundColor: '#1E293B',
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 16,
    borderWidth: 2,
    borderColor: '#334155',
  },
  imageUploadButtons: {
    flexDirection: 'row',
    justifyContent: 'center',
    gap: 16,
  },
  imageUploadButton: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#7C3AED',
    paddingVertical: 10,
    paddingHorizontal: 16,
    borderRadius: 8,
    gap: 8,
  },
  imageUploadButtonText: {
    color: '#FFFFFF',
    fontWeight: '600',
  },
});

export default JoinScreen;