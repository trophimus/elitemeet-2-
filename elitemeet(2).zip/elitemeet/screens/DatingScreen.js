// Dating Screen Page
import React, { useState, useEffect } from 'react';
import { View, Text, Image, TouchableOpacity, ScrollView, ActivityIndicator } from 'react-native';
import { Heart, MessageCircle, X, Check, Star, MapPin } from 'lucide-react-native';
import { styles } from '../assets/styles';

const DatingScreen = () => {
  const [profiles, setProfiles] = useState([]);
  const [loading, setLoading] = useState(true);
  const [currentIndex, setCurrentIndex] = useState(0);

  // Mock data for elite dating profiles
  useEffect(() => {
    setTimeout(() => {
      setProfiles([
        {
          id: '1',
          name: 'Sophia Laurent',
          age: 29,
          title: 'Art Gallery Owner',
          location: 'Paris, France',
          bio: 'Contemporary art collector with passion for philanthropy',
          netWorth: '$8M+',
          verified: true,
          premium: true,
          photo: 'https://example.com/sophia.jpg'
        },
        {
          id: '2',
          name: 'Michael Chen',
          age: 35,
          title: 'Tech Entrepreneur',
          location: 'San Francisco, USA',
          bio: 'Series B founder looking for meaningful connections',
          netWorth: '$15M+',
          verified: true,
          premium: false,
          photo: 'https://example.com/michael.jpg'
        }
      ]);
      setLoading(false);
    }, 1500);
  }, []);

  const handleSwipe = (direction) => {
    if (direction === 'right') {
      console.log('Liked:', profiles[currentIndex].name);
    } else {
      console.log('Passed:', profiles[currentIndex].name);
    }
    setCurrentIndex(prev => prev + 1);
  };

  if (loading) {
    return <ActivityIndicator size="large" color="#8B5CF6" style={styles.loader} />;
  }

  if (currentIndex >= profiles.length) {
    return (
      <View style={styles.noMoreContainer}>
        <Text style={styles.noMoreText}>No more profiles in your area</Text>
        <Text style={styles.noMoreSubtext}>Try adjusting your preferences</Text>
      </View>
    );
  }

  const currentProfile = profiles[currentIndex];

  return (
    <View style={styles.datingContainer}>
      {/* Profile Card */}
      <View style={styles.profileCard}>
        <Image 
          source={{ uri: currentProfile.photo }} 
          style={styles.profileImage}
          resizeMode="cover"
        />
        
        {/* Verification Badge */}
        {currentProfile.verified && (
          <View style={styles.verifiedBadge}>
            <Text style={styles.verifiedText}>✓ Verified</Text>
          </View>
        )}
        
        {/* Premium Badge */}
        {currentProfile.premium && (
          <View style={styles.premiumBadge}>
            <Star size={14} color="#F59E0B" />
            <Text style={styles.premiumText}>Elite Member</Text>
          </View>
        )}
        
        {/* Profile Info */}
        <View style={styles.profileInfo}>
          <View style={styles.nameAgeContainer}>
            <Text style={styles.profileName}>{currentProfile.name}, {currentProfile.age}</Text>
          </View>
          <Text style={styles.profileTitle}>{currentProfile.title}</Text>
          
          <View style={styles.locationContainer}>
            <MapPin size={16} color="#94A3B8" />
            <Text style={styles.profileLocation}>{currentProfile.location}</Text>
          </View>
          
          <Text style={styles.profileBio}>{currentProfile.bio}</Text>
          
          <View style={styles.netWorthContainer}>
            <Text style={styles.netWorthLabel}>Estimated Net Worth:</Text>
            <Text style={styles.netWorthValue}>{currentProfile.netWorth}</Text>
          </View>
        </View>
      </View>
      
      {/* Action Buttons */}
      <View style={styles.actionButtons}>
        <TouchableOpacity 
          style={[styles.actionButton, styles.passButton]}
          onPress={() => handleSwipe('left')}
        >
          <X size={32} color="#EF4444" />
        </TouchableOpacity>
        
        <TouchableOpacity 
          style={[styles.actionButton, styles.messageButton]}
          onPress={() => console.log('Message', currentProfile.name)}
        >
          <MessageCircle size={28} color="#8B5CF6" />
        </TouchableOpacity>
        
        <TouchableOpacity 
          style={[styles.actionButton, styles.likeButton]}
          onPress={() => handleSwipe('right')}
        >
          <Heart size={32} color="#10B981" fill="#10B981" />
        </TouchableOpacity>
      </View>
    </View>
  );
};

export default DatingScreen;