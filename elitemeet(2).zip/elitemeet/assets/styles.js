// Global Styles for EliteMeet App

import { StyleSheet, Dimensions } from 'react-native';

const { width, height } = Dimensions.get('window');

export const styles = StyleSheet.create({
  // General Containers
  container: {
    flex: 1,
    backgroundColor: '#0F172A', // Dark Slate Blue
    padding: 20,
    paddingTop: 40,
  },
  homeContainer: {
    flex: 1,
    backgroundColor: '#0F172A',
    paddingHorizontal: 20,
    paddingTop: 40,
  },
  loader: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#0F172A',
  },
  
  // Header
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 20,
  },
  appTitle: {
    fontSize: 28,
    fontWeight: 'bold',
    color: '#8B5CF6', // Purple
    textShadowColor: 'rgba(139, 92, 246, 0.5)',
    textShadowOffset: { width: 0, height: 2 },
    textShadowRadius: 8,
  },
  icons: {
    flexDirection: 'row',
    gap: 20,
  },

  // Mode Switcher
  modeSwitcherContainer: {
    flexDirection: 'row',
    backgroundColor: '#1E293B', // Darker Blue
    borderRadius: 30,
    padding: 6,
    marginBottom: 20,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.3,
    shadowRadius: 5,
    elevation: 8,
  },
  modeButton: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 12,
    paddingHorizontal: 15,
    borderRadius: 25,
  },
  activeModeButton: {
    backgroundColor: '#8B5CF6', // Purple
    shadowColor: '#8B5CF6',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.5,
    shadowRadius: 5,
    elevation: 10,
  },
  modeButtonText: {
    color: '#94A3B8', // Gray
    fontSize: 16,
    fontWeight: '600',
    marginLeft: 8,
  },
  activeModeButtonText: {
    color: '#FFFFFF',
  },

  // Search Bar
  searchBar: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#1E293B',
    borderRadius: 12,
    paddingHorizontal: 15,
    paddingVertical: 10,
    marginBottom: 20,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.2,
    shadowRadius: 4,
    elevation: 5,
  },
  searchInput: {
    flex: 1,
    color: '#E2E8F0', // Light Gray
    fontSize: 16,
    marginLeft: 10,
  },
  searchIcon: {
    marginRight: 5,
  },

  // Profile Card (Home Screen)
  card: {
    backgroundColor: '#1E293B',
    marginBottom: 15,
    borderRadius: 15,
    overflow: 'hidden',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 6 },
    shadowOpacity: 0.4,
    shadowRadius: 10,
    elevation: 12,
  },
  cardImage: {
    width: '100%',
    height: 200,
    borderTopLeftRadius: 15,
    borderTopRightRadius: 15,
  },
  cardContent: {
    padding: 15,
  },
  cardHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 5,
  },
  name: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#FFFFFF',
  },
  verifiedBadge: {
    backgroundColor: '#10B981', // Green
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 20,
    alignSelf: 'flex-start',
  },
  verifiedText: {
    color: '#FFFFFF',
    fontSize: 12,
    fontWeight: 'bold',
  },
  title: {
    fontSize: 16,
    color: '#8B5CF6',
    fontWeight: '600',
    marginBottom: 5,
  },
  company: {
    fontSize: 14,
    color: '#94A3B8',
    marginBottom: 10,
  },
  detailsContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 5,
  },
  detailsText: {
    fontSize: 14,
    color: '#E2E8F0',
    marginLeft: 5,
  },
  button: {
    backgroundColor: '#8B5CF6',
    paddingVertical: 12,
    borderRadius: 10,
    alignItems: 'center',
    marginTop: 10,
    shadowColor: '#8B5CF6',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.5,
    shadowRadius: 8,
    elevation: 10,
  },
  buttonText: {
    color: '#FFFFFF',
    fontSize: 16,
    fontWeight: 'bold',
  },
  
  // Dating Screen Specific
  datingContainer: {
    flex: 1,
    backgroundColor: '#0F172A',
    justifyContent: 'center',
    alignItems: 'center',
  },
  profileCard: {
    width: width * 0.9,
    height: height * 0.7,
    backgroundColor: '#1E293B',
    borderRadius: 20,
    overflow: 'hidden',
    shadowColor: '#8B5CF6',
    shadowOffset: { width: 0, height: 10 },
    shadowOpacity: 0.6,
    shadowRadius: 20,
    elevation: 20,
    marginBottom: 30,
  },
  profileImage: {
    width: '100%',
    height: '60%',
  },
  premiumBadge: {
    position: 'absolute',
    top: 15,
    left: 15,
    backgroundColor: '#F59E0B', // Amber
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 10,
    paddingVertical: 5,
    borderRadius: 20,
    shadowColor: '#F59E0B',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.8,
    shadowRadius: 5,
    elevation: 8,
  },
  premiumText: {
    color: '#FFFFFF',
    fontSize: 12,
    fontWeight: 'bold',
    marginLeft: 5,
  },
  profileInfo: {
    padding: 20,
    height: '40%',
    justifyContent: 'space-between',
  },
  nameAgeContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  profileName: {
    fontSize: 28,
    fontWeight: 'bold',
    color: '#FFFFFF',
  },
  profileTitle: {
    fontSize: 18,
    color: '#8B5CF6',
    fontWeight: '600',
    marginTop: 5,
  },
  locationContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    marginTop: 10,
  },
  profileLocation: {
    fontSize: 16,
    color: '#94A3B8',
    marginLeft: 5,
  },
  profileBio: {
    fontSize: 16,
    color: '#E2E8F0',
    lineHeight: 24,
    marginTop: 10,
  },
  netWorthContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    marginTop: 15,
  },
  netWorthLabel: {
    fontSize: 14,
    color: '#94A3B8',
    fontWeight: 'bold',
    marginRight: 5,
  },
  netWorthValue: {
    fontSize: 16,
    color: '#10B981', // Green
    fontWeight: 'bold',
  },
  actionButtons: {
    flexDirection: 'row',
    justifyContent: 'space-around',
    width: '80%',
  },
  actionButton: {
    backgroundColor: '#1E293B',
    borderRadius: 50,
    padding: 18,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 6 },
    shadowOpacity: 0.4,
    shadowRadius: 10,
    elevation: 12,
  },
  passButton: {
    backgroundColor: '#EF4444', // Red
    shadowColor: '#EF4444',
  },
  messageButton: {
    backgroundColor: '#8B5CF6', // Purple
    shadowColor: '#8B5CF6',
  },
  likeButton: {
    backgroundColor: '#10B981', // Green
    shadowColor: '#10B981',
  },
  noMoreContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#0F172A',
    padding: 20,
  },
  noMoreText: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#FFFFFF',
    textAlign: 'center',
    marginBottom: 10,
  },
  noMoreSubtext: {
    fontSize: 16,
    color: '#94A3B8',
    textAlign: 'center',
  },

  // Auth Screen Specific
  authContainer: {
    flex: 1,
    backgroundColor: '#0F172A',
  },
  authScrollContainer: {
    flexGrow: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 20,
  },
  authLogo: {
    width: 150,
    height: 150,
    marginBottom: 30,
    borderRadius: 75,
    borderWidth: 3,
    borderColor: '#8B5CF6',
    shadowColor: '#8B5CF6',
    shadowOffset: { width: 0, height: 0 },
    shadowOpacity: 0.8,
    shadowRadius: 15,
    elevation: 20,
  },
  authTitle: {
    fontSize: 32,
    fontWeight: 'bold',
    color: '#FFFFFF',
    marginBottom: 30,
    textShadowColor: 'rgba(255, 255, 255, 0.3)',
    textShadowOffset: { width: 0, height: 2 },
    textShadowRadius: 10,
  },
  inputContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#1E293B',
    borderRadius: 12,
    paddingHorizontal: 15,
    marginBottom: 15,
    width: '100%',
    maxWidth: 400,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.3,
    shadowRadius: 5,
    elevation: 8,
  },
  inputIcon: {
    marginRight: 10,
  },
  authInput: {
    flex: 1,
    height: 50,
    color: '#E2E8F0',
    fontSize: 16,
  },
  authButton: {
    backgroundColor: '#8B5CF6',
    paddingVertical: 15,
    borderRadius: 12,
    width: '100%',
    maxWidth: 400,
    alignItems: 'center',
    marginTop: 20,
    shadowColor: '#8B5CF6',
    shadowOffset: { width: 0, height: 8 },
    shadowOpacity: 0.6,
    shadowRadius: 15,
    elevation: 15,
    transform: [{ translateY: 0 }],
  },
  authButtonText: {
    color: '#FFFFFF',
    fontSize: 18,
    fontWeight: 'bold',
  },
  authToggleText: {
    color: '#8B5CF6',
    fontSize: 16,
    marginTop: 20,
    fontWeight: '600',
    textDecorationLine: 'underline',
  },
  authPrivacyText: {
    color: '#64748B',
    fontSize: 12,
    textAlign: 'center',
    marginTop: 30,
    lineHeight: 18,
  },

  // Profile Edit Screen
  profileEditContainer: {
    flex: 1,
    backgroundColor: '#0F172A',
    padding: 20,
  },
  profileHeader: {
    alignItems: 'center',
    marginBottom: 30,
  },
  profileAvatar: {
    width: 120,
    height: 120,
    borderRadius: 60,
    backgroundColor: '#1E293B',
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 15,
    borderWidth: 2,
    borderColor: '#8B5CF6',
  },
  profileAvatarImage: {
    width: '100%',
    height: '100%',
    borderRadius: 60,
  },
  changePhotoText: {
    color: '#8B5CF6',
    fontSize: 16,
    fontWeight: '600',
  },
  sectionTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#FFFFFF',
    marginBottom: 15,
    marginTop: 20,
    borderBottomWidth: 1,
    borderBottomColor: '#1E293B',
    paddingBottom: 5,
  },
  multiLineInput: {
    height: 100,
    textAlignVertical: 'top',
    paddingTop: 15,
  },

  // LLM Advice Screen
  llmContainer: {
    flex: 1,
    backgroundColor: '#0F172A',
    padding: 20,
  },
  llmTitle: {
    fontSize: 26,
    fontWeight: 'bold',
    color: '#FFFFFF',
    marginBottom: 20,
    textAlign: 'center',
  },
  adviceOptions: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'center',
    marginBottom: 20,
    gap: 10,
  },
  adviceButton: {
    backgroundColor: '#1E293B',
    paddingVertical: 10,
    paddingHorizontal: 15,
    borderRadius: 20,
    borderWidth: 1,
    borderColor: '#8B5CF6',
  },
  activeAdviceButton: {
    backgroundColor: '#8B5CF6',
  },
  adviceButtonText: {
    color: '#FFFFFF',
    fontSize: 14,
    fontWeight: '500',
  },
  llmOutputContainer: {
    backgroundColor: '#1E293B',
    borderRadius: 10,
    padding: 15,
    marginTop: 20,
    minHeight: 150,
    shadowColor: '#8B5CF6',
    shadowOffset: { width: 0, height: 0 },
    shadowOpacity: 0.4,
    shadowRadius: 10,
    elevation: 8,
  },
  llmOutputText: {
    color: '#E2E8F0',
    fontSize: 15,
    lineHeight: 22,
  },

  // Chat Screen
  chatContainer: {
    flex: 1,
    backgroundColor: '#0F172A',
  },
  chatHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: 15,
    borderBottomWidth: 1,
    borderBottomColor: '#1E293B',
    backgroundColor: '#1E293B',
  },
  chatHeaderText: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#FFFFFF',
    marginLeft: 15,
  },
  messagesContainer: {
    flex: 1,
    padding: 15,
  },
  messageBubble: {
    maxWidth: '80%',
    padding: 10,
    borderRadius: 15,
    marginBottom: 10,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.2,
    shadowRadius: 3,
    elevation: 3,
  },
  myMessage: {
    alignSelf: 'flex-end',
    backgroundColor: '#8B5CF6',
    borderBottomRightRadius: 2,
  },
  otherMessage: {
    alignSelf: 'flex-start',
    backgroundColor: '#334155', // Blue Gray
    borderBottomLeftRadius: 2,
  },
  messageText: {
    color: '#FFFFFF',
    fontSize: 16,
  },
  messageTime: {
    fontSize: 10,
    color: '#E2E8F0',
    alignSelf: 'flex-end',
    marginTop: 5,
  },
  chatInputContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: 15,
    borderTopWidth: 1,
    borderTopColor: '#1E293B',
    backgroundColor: '#1E293B',
  },
  chatTextInput: {
    flex: 1,
    backgroundColor: '#0F172A',
    borderRadius: 25,
    paddingHorizontal: 15,
    paddingVertical: 10,
    color: '#FFFFFF',
    marginRight: 10,
    fontSize: 16,
  },
  sendButton: {
    backgroundColor: '#8B5CF6',
    borderRadius: 25,
    padding: 10,
    justifyContent: 'center',
    alignItems: 'center',
  },
  
});
