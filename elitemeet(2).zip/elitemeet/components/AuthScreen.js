
// AuthScreen.js - Authentication Page

import React, { useState, useEffect } from 'react';
import { 
  View, 
  Text, 
  TextInput, 
  TouchableOpacity, 
  Image, 
  KeyboardAvoidingView, 
  Platform, 
  ScrollView,
  ActivityIndicator,
} from 'react-native';
import { Lock, Mail, Eye, EyeOff, User, Briefcase, DollarSign } from 'lucide-react-native';
import { styles } from '../assets/styles';
import AuthService from '../services/auth'; // Ensure correct import path
import DatabaseService from '../database/Database'; // Import DatabaseService

const AuthScreen = ({ navigation }) => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [isLogin, setIsLogin] = useState(true); // Default to Login
  const [fullName, setFullName] = useState(''); // New field for registration
  const [profession, setProfession] = useState('');
  const [netWorth, setNetWorth] = useState('');
  const [loading, setLoading] = useState(false);
  const [errorMessage, setErrorMessage] = useState('');

  // Effect to navigate if already authenticated
  useEffect(() => {
    const checkAuthStatus = async () => {
      setLoading(true); // Start loading when component mounts
      // Ensure Firebase auth is ready before fetching
      while (!DatabaseService.isAuthInitialized()) {
        await new Promise(resolve => setTimeout(resolve, 100));
      }
      const authenticated = await AuthService.isAuthenticated();
      if (authenticated) {
        // Navigate to Home if already logged in
        navigation.replace('Home'); 
      }
      setLoading(false); // Stop loading after checking auth
    };
    checkAuthStatus();
  }, [navigation]); // Added navigation to dependency array


  const handleAuth = async () => {
    setLoading(true);
    setErrorMessage(''); // Clear previous errors

    if (isLogin) {
      // Login
      const { success, error, user } = await AuthService.login(email, password);
      if (success) {
        console.log("Logged in successfully:", user);
        navigation.replace('Home'); // Navigate to Home after successful login
      } else {
        setErrorMessage(error || 'Login failed. Please check your credentials.');
      }
    } else {
      // Register
      if (!fullName || !profession || !netWorth) {
        setErrorMessage('Please fill in all registration fields.');
        setLoading(false);
        return;
      }
      const userData = { email, password, fullName, profession, netWorth };
      const { success, error, user } = await AuthService.register(userData);
      if (success) {
        console.log("Registered successfully:", user);
        // After successful registration, save additional profile data to Firestore
        const currentUserId = DatabaseService.getCurrentUserId();
        if (currentUserId) {
          const profileData = {
            fullName: userData.fullName, // Make sure fullName is included
            email: userData.email,
            profession: userData.profession,
            netWorth: userData.netWorth,
            // Add other default profile fields
            bio: "Elite member looking for connections.",
            location: "Global",
            photo: "https://placehold.co/150x150/8B5CF6/FFFFFF?text=PROFILE", // Default placeholder
            verified: false,
            premium: false,
          };
          const dbResult = await DatabaseService.createUserProfile(currentUserId, profileData);
          if (dbResult.success) {
            console.log("Profile created in Firestore:", profileData);
            // Add to public profiles for matching
            const publicProfileResult = await DatabaseService.addPublicProfile({
              userId: currentUserId,
              name: userData.fullName,
              title: userData.profession,
              netWorth: userData.netWorth,
              location: "Global", // Default location
              bio: "Elite member looking for connections.",
              photo: "https://placehold.co/150x150/8B5CF6/FFFFFF?text=PROFILE",
              verified: false,
              type: 'dating' // Default type for public profiles
            });
            if (!publicProfileResult.success) {
              console.error("Failed to add public profile:", publicProfileResult.error);
            }
          } else {
            console.error("Failed to create profile in Firestore:", dbResult.error);
          }
        }
        navigation.replace('Home'); // Navigate to Home after successful registration
      } else {
        setErrorMessage(error || 'Registration failed. Please try again.');
      }
    }
    setLoading(false);
  };

  const toggleAuthMode = () => {
    setIsLogin(!isLogin);
    setErrorMessage(''); // Clear errors when switching mode
  };

  // If loading initially, show only activity indicator
  if (loading && !isAuthenticated) {
    return (
      <View style={styles.loader}>
        <ActivityIndicator size="large" color="#8B5CF6" />
        <Text style={{color: '#E2E8F0', marginTop: 10}}>Checking authentication...</Text>
      </View>
    );
  }

  return (
    <KeyboardAvoidingView 
      behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
      style={styles.authContainer}
    >
      <ScrollView contentContainerStyle={styles.authScrollContainer}>
        {/* App Logo */}
        <Image 
          source={require('../assets/elitemeet-logo.png')} // Changed to .png
          style={styles.authLogo}
        />
        
        <Text style={styles.authTitle}>
          {isLogin ? 'Welcome Back' : 'Join Elite Network'}
        </Text>

        {/* Display Error Message */}
        {errorMessage ? (
          <Text style={{ color: '#EF4444', marginBottom: 15, textAlign: 'center' }}>
            {errorMessage}
          </Text>
        ) : null}

        {/* Email Input */}
        <View style={styles.inputContainer}>
          <Mail size={20} color="#94A3B8" style={styles.inputIcon} />
          <TextInput
            style={styles.authInput}
            placeholder="Email Address"
            placeholderTextColor="#64748B"
            value={email}
            onChangeText={setEmail}
            keyboardType="email-address"
            autoCapitalize="none"
          />
        </View>

        {/* Password Input */}
        <View style={styles.inputContainer}>
          <Lock size={20} color="#94A3B8" style={styles.inputIcon} />
          <TextInput
            style={styles.authInput}
            placeholder="Password"
            placeholderTextColor="#64748B"
            secureTextEntry={!showPassword}
            value={password}
            onChangeText={setPassword}
          />
          <TouchableOpacity onPress={() => setShowPassword(!showPassword)}>
            {showPassword ? 
              <EyeOff size={20} color="#94A3B8" /> : 
              <Eye size={20} color="#94A3B8" />
            }
          </TouchableOpacity>
        </View>

        {/* Additional Fields for Registration */}
        {!isLogin && (
          <>
            <View style={styles.inputContainer}>
              <User size={20} color="#94A3B8" style={styles.inputIcon} />
              <TextInput
                style={styles.authInput}
                placeholder="Full Name"
                placeholderTextColor="#64748B"
                value={fullName}
                onChangeText={setFullName}
              />
            </View>
            <View style={styles.inputContainer}>
              <Briefcase size={20} color="#94A3B8" style={styles.inputIcon} />
              <TextInput
                style={styles.authInput}
                placeholder="Profession/Title"
                placeholderTextColor="#64748B"
                value={profession}
                onChangeText={setProfession}
              />
            </View>

            <View style={styles.inputContainer}>
              <DollarSign size={20} color="#94A3B8" style={styles.inputIcon} />
              <TextInput
                style={styles.authInput}
                placeholder="Estimated Net Worth (USD)"
                placeholderTextColor="#64748B"
                value={netWorth}
                onChangeText={setNetWorth}
                keyboardType="numeric"
              />
            </View>
          </>
        )}

        {/* Auth Button */}
        <TouchableOpacity 
          style={styles.authButton}
          onPress={handleAuth}
          disabled={loading}
        >
          {loading ? (
            <ActivityIndicator color="#FFFFFF" />
          ) : (
            <Text style={styles.authButtonText}>
              {isLogin ? 'Sign In' : 'Apply for Membership'}
            </Text>
          )}
        </TouchableOpacity>

        {/* Switch Auth Mode */}
        <TouchableOpacity onPress={toggleAuthMode}>
          <Text style={styles.authToggleText}>
            {isLogin ? 
              "Don't have an account? Apply Now" : 
              "Already a member? Sign In"
            }
          </Text>
        </TouchableOpacity>

        {/* Privacy Notice */}
        <Text style={styles.authPrivacyText}>
          By continuing, you agree to our Terms and Privacy Policy
        </Text>
      </ScrollView>
    </KeyboardAvoidingView>
  );
};

export default AuthScreen;
