// For user to switch modes
import React from 'react';
import { View, TouchableOpacity, Text } from 'react-native';
import { Heart, Briefcase } from 'lucide-react-native';
import { styles } from '../assets/styles';

export default function ModeSwitcher({ activeTab, setActiveTab }) {
  return (
    <View style={styles.modeSwitcherContainer}>
      <TouchableOpacity
        style={[
          styles.modeButton,
          activeTab === 'dating' && styles.activeModeButton,
        ]}
        onPress={() => setActiveTab('dating')}
      >
        <Heart size={16} color={activeTab === 'dating' ? '#FFFFFF' : '#94A3B8'} />
        <Text style={[
          styles.modeButtonText,
          activeTab === 'dating' && styles.activeModeButtonText,
        ]}>
          Dating
        </Text>
      </TouchableOpacity>

      <TouchableOpacity
        style={[
          styles.modeButton,
          activeTab === 'investors' && styles.activeModeButton,
        ]}
        onPress={() => setActiveTab('investors')}
      >
        <Briefcase size={16} color={activeTab === 'investors' ? '#FFFFFF' : '#94A3B8'} />
        <Text style={[
          styles.modeButtonText,
          activeTab === 'investors' && styles.activeModeButtonText,
        ]}>
          Investors
        </Text>
      </TouchableOpacity>
    </View>
  );
}