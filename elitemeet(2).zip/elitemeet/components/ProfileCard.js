// ProfileCard.js - Component to display a single user/investor profile card

import React from 'react';
import { View, Text, Image, TouchableOpacity } from 'react-native';
import { Briefcase, DollarSign, MapPin, Heart, Star } from 'lucide-react-native'; // Import icons for better visuals
import { styles } from '../assets/styles'; // Import global styles

export default function ProfileCard({ profile, mode, onPress }) {
  // Determine if it's a dating profile to show age and specific dating info
  const isDatingProfile = mode === 'dating';
  // Default photo if none is provided
  const defaultPhoto = 'https://placehold.co/150x150/8B5CF6/FFFFFF?text=PROFILE';

  return (
    <TouchableOpacity onPress={onPress} style={styles.card}>
      {/* Profile Image */}
      <Image
        source={{ uri: profile.photo || defaultPhoto }}
        style={styles.cardImage}
        resizeMode="cover"
        onError={(e) => console.log('Image load error:', e.nativeEvent.error)}
      />

      <View style={styles.cardContent}>
        {/* Header: Name, Age (if dating), Verified Badge */}
        <View style={styles.cardHeader}>
          <Text style={styles.name}>
            {profile.name}
            {isDatingProfile && profile.age ? `, ${profile.age}` : ''}
          </Text>
          {profile.verified && (
            <View style={styles.verifiedBadge}>
              <Text style={styles.verifiedText}>✓ Verified</Text>
            </View>
          )}
        </View>

        {/* Title/Profession */}
        <Text style={styles.title}>{profile.title}</Text>
        
        {/* Company (if available) */}
        {profile.company && <Text style={styles.company}>{profile.company}</Text>}

        {/* Conditional Details based on mode */}
        {isDatingProfile ? (
          // Dating Profile specific details
          <>
            {profile.location && (
              <View style={styles.detailsContainer}>
                <MapPin size={16} color="#94A3B8" />
                <Text style={styles.detailsText}>{profile.location}</Text>
              </View>
            )}
            {profile.netWorth && (
              <View style={styles.detailsContainer}>
                <DollarSign size={16} color="#10B981" />
                <Text style={styles.detailsText}>Net Worth: {profile.netWorth}</Text>
              </View>
            )}
            {profile.bio && (
              <Text style={[styles.detailsText, { marginTop: 10 }]}>
                {profile.bio.length > 70 ? profile.bio.substring(0, 70) + '...' : profile.bio}
              </Text>
            )}
          </>
        ) : (
          // Investor Profile specific details
          <>
            {profile.focus && (
              <View style={styles.detailsContainer}>
                <Briefcase size={16} color="#8B5CF6" />
                <Text style={styles.detailsText}>Focus: {profile.focus}</Text>
              </View>
            )}
            {profile.checkSize && (
              <View style={styles.detailsContainer}>
                <DollarSign size={16} color="#10B981" />
                <Text style={styles.detailsText}>Check Size: {profile.checkSize}</Text>
              </View>
            )}
            {profile.aum && (
              <View style={styles.detailsContainer}>
                <Star size={16} color="#F59E0B" />
                <Text style={styles.detailsText}>AUM: {profile.aum}</Text>
              </View>
            )}
            {profile.pitch && (
              <Text style={[styles.detailsText, { marginTop: 10 }]}>
                {profile.pitch.length > 70 ? profile.pitch.substring(0, 70) + '...' : profile.pitch}
              </Text>
            )}
          </>
        )}
      </View>
    </TouchableOpacity>
  );
}
