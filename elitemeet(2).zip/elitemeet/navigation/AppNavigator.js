// for selection(navigation)
// App.js - Main entry point for EliteMeet
import React, { useState, useEffect } from 'react';
import { ActivityIndicator, View, Text } from 'react-native';
import AppNavigator from '../navigation/APPNavigator';
import AuthScreen from './screens/AuthScreen';
import DatabaseService from './database/Database'; // Import DatabaseService
import { onAuthStateChanged } from 'firebase/auth';
import { styles } from './assets/styles';

export default function App() {
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    // Wait for Firebase authentication to be ready
    const checkAuthReady = setInterval(() => {
      if (DatabaseService.isAuthInitialized()) {
        clearInterval(checkAuthReady);
        const auth = DatabaseService.getAuthInstance();
        // Listen for auth state changes
        const unsubscribe = onAuthStateChanged(auth, (user) => {
          if (user) {
            console.log("App.js: User is logged in.", user.uid);
            setIsAuthenticated(true);
          } else {
            console.log("App.js: No user is logged in.");
            setIsAuthenticated(false);
          }
          setLoading(false);
        });
        return () => unsubscribe(); // Cleanup the listener
      }
    }, 100); // Check every 100ms
    return () => clearInterval(checkAuthReady); // Cleanup interval on unmount
  }, []);

  if (loading) {
    return (
      <View style={styles.loader}>
        <ActivityIndicator size="large" color="#8B5CF6" />
        <Text style={{color: '#E2E8F0', marginTop: 10}}>Loading EliteMeet...</Text>
      </View>
    );
  }

  // Render AppNavigator if authenticated, else render AuthScreen
  return isAuthenticated ? <AppNavigator /> : <AuthScreen />;
}